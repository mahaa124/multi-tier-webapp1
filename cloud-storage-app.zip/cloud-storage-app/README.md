# Cloud-Based File Storage System

A secure cloud storage app (Google-Drive-style) with OAuth 2.0 login,
pre-signed S3 uploads/downloads, file versioning, and sharing.

## Architecture

```
                    ┌──────────────┐
   Users ──────────▶│   Frontend   │ (static SPA demo)
                    └──────┬───────┘
                           │
                    ┌──────▼───────┐
                    │  Backend API  │ (Express + OAuth + S3 pre-signed URLs)
                    └──┬────────┬──┘
                       │        │
              ┌────────▼──┐  ┌──▼──────────┐
              │ PostgreSQL│  │  AWS S3     │ (actual file bytes)
              │ (metadata,│  │  bucket     │
              │ versions, │  └─────────────┘
              │ shares)   │
              └───────────┘
```

Files never pass through the backend — the browser uploads/downloads
directly to/from S3 using short-lived pre-signed URLs. The backend and
database only ever handle metadata (filenames, owners, version
history, share permissions).

## Folder structure

```
cloud-storage-app/
├── backend/
│   ├── src/
│   │   ├── index.js          # Express app entry point
│   │   ├── auth.js           # OAuth 2.0 (Google) login + JWT sessions
│   │   ├── s3.js             # Pre-signed upload/download URL helpers
│   │   └── routes/
│   │       ├── files.js      # Upload, list, download, delete
│   │       ├── versions.js   # Version history + restore
│   │       └── shares.js     # Share with user / share link
│   ├── db/
│   │   └── schema.sql        # PostgreSQL schema
│   ├── Dockerfile
│   └── package.json
├── frontend/
│   ├── public/
│   │   ├── index.html
│   │   └── style.css
│   └── src/
│       └── app.js            # Login + file list + upload demo
└── README.md
```

## Getting started

### 1. Database
```bash
createdb cloud_storage
psql cloud_storage < backend/db/schema.sql
```

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env      # fill in your values
npm run dev                # http://localhost:4000
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev                # http://localhost:3000
```

## Required environment variables (`backend/.env`)

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection string |
| `JWT_SECRET` | Signs session tokens |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | OAuth 2.0 credentials |
| `OAUTH_REDIRECT_URI` | e.g. `http://localhost:4000/auth/google/callback` |
| `AWS_REGION` | e.g. `us-east-1` |
| `S3_BUCKET_NAME` | Your private storage bucket |

## Security notes baked into this scaffold

- Bucket stays private — all access goes through pre-signed URLs with short expiry.
- Every S3 key is prefixed with the user's ID for isolation.
- Sessions use short-lived JWTs; refresh tokens are stored httpOnly (not localStorage).
- Share links use a random unguessable token with optional expiry, never sequential IDs.
- See `backend/db/schema.sql` for the full metadata model (files, versions, shares, audit log).
