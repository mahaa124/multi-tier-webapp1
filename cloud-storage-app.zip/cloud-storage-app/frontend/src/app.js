const API_BASE_URL = window.API_BASE_URL || "http://localhost:4000";

const log = (msg) => {
  document.getElementById("log").textContent =
    typeof msg === "string" ? msg : JSON.stringify(msg, null, 2);
};

// --- Login ---
document.getElementById("loginBtn").addEventListener("click", () => {
  window.location.href = `${API_BASE_URL}/auth/google`;
});

// If we just got redirected back from a successful login, flip the UI.
if (new URLSearchParams(window.location.search).get("login") === "success") {
  document.getElementById("loggedOut").style.display = "none";
  document.getElementById("loggedIn").style.display = "block";
  loadFiles();
}

// --- Upload flow: ask backend for a pre-signed URL, upload straight to S3 ---
document.getElementById("uploadBtn").addEventListener("click", async () => {
  const fileInput = document.getElementById("fileInput");
  const file = fileInput.files[0];
  if (!file) return log("Choose a file first.");

  try {
    log("Requesting upload URL...");
    const res = await fetch(`${API_BASE_URL}/api/files/upload-url`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ fileName: file.name, contentType: file.type }),
    });
    const { fileId, uploadUrl } = await res.json();

    log("Uploading directly to S3...");
    await fetch(uploadUrl, { method: "PUT", body: file, headers: { "Content-Type": file.type } });

    await fetch(`${API_BASE_URL}/api/files/${fileId}/complete`, {
      method: "POST",
      credentials: "include",
    });

    log(`Uploaded ${file.name} successfully.`);
    loadFiles();
  } catch (err) {
    log(`Upload failed: ${err.message}`);
  }
});

async function loadFiles() {
  try {
    const res = await fetch(`${API_BASE_URL}/api/files`, { credentials: "include" });
    const { files } = await res.json();
    const list = document.getElementById("fileList");
    list.innerHTML = "";
    files.forEach((f) => {
      const li = document.createElement("li");
      li.textContent = f.name;
      list.appendChild(li);
    });
  } catch (err) {
    log(`Could not load files: ${err.message}`);
  }
}
