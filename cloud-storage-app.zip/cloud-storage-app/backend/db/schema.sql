-- Cloud Storage App — metadata schema
-- File bytes live in S3; this DB only tracks metadata.

CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email          VARCHAR(255) UNIQUE NOT NULL,
  name           VARCHAR(255),
  oauth_provider VARCHAR(50) NOT NULL,     -- e.g. 'google'
  oauth_sub      VARCHAR(255) NOT NULL,    -- provider's unique user id
  created_at     TIMESTAMP DEFAULT now()
);

CREATE TABLE folders (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id         UUID REFERENCES users(id) ON DELETE CASCADE,
  parent_folder_id UUID REFERENCES folders(id) ON DELETE CASCADE,
  name             VARCHAR(255) NOT NULL,
  created_at       TIMESTAMP DEFAULT now()
);

CREATE TABLE files (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id            UUID REFERENCES users(id) ON DELETE CASCADE,
  folder_id           UUID REFERENCES folders(id) ON DELETE SET NULL,
  name                VARCHAR(255) NOT NULL,
  mime_type           VARCHAR(127),
  size_bytes          BIGINT,
  current_version_id  UUID,               -- points at file_versions.id
  status              VARCHAR(20) DEFAULT 'pending', -- pending | active | deleted
  created_at          TIMESTAMP DEFAULT now(),
  updated_at          TIMESTAMP DEFAULT now()
);

CREATE TABLE file_versions (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id       UUID REFERENCES files(id) ON DELETE CASCADE,
  s3_key        VARCHAR(512) NOT NULL,
  s3_version_id VARCHAR(255),             -- S3's native VersionId, if bucket versioning is on
  size_bytes    BIGINT,
  uploaded_by   UUID REFERENCES users(id),
  created_at    TIMESTAMP DEFAULT now()
);

ALTER TABLE files
  ADD CONSTRAINT fk_current_version
  FOREIGN KEY (current_version_id) REFERENCES file_versions(id);

CREATE TABLE shares (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  file_id      UUID REFERENCES files(id) ON DELETE CASCADE,
  shared_by    UUID REFERENCES users(id),
  shared_with  UUID REFERENCES users(id),      -- nullable = "anyone with link"
  permission   VARCHAR(10) CHECK (permission IN ('view', 'edit')) NOT NULL,
  link_token   VARCHAR(64) UNIQUE,              -- set only for link-based shares
  expires_at   TIMESTAMP,
  created_at   TIMESTAMP DEFAULT now()
);

CREATE TABLE audit_log (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID REFERENCES users(id),
  file_id    UUID REFERENCES files(id),
  action     VARCHAR(50) NOT NULL,   -- upload | download | share | delete | restore_version
  metadata   JSONB,
  created_at TIMESTAMP DEFAULT now()
);

CREATE INDEX idx_files_owner ON files(owner_id);
CREATE INDEX idx_files_folder ON files(folder_id);
CREATE INDEX idx_versions_file ON file_versions(file_id);
CREATE INDEX idx_shares_file ON shares(file_id);
CREATE INDEX idx_shares_shared_with ON shares(shared_with);
CREATE INDEX idx_shares_link_token ON shares(link_token);
