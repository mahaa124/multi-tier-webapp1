const express = require("express");
const crypto = require("crypto");
const router = express.Router();
const { requireAuth } = require("../auth");

// Share a file directly with another user by email.
router.post("/:fileId/user", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  const { email, permission } = req.body; // permission: 'view' | 'edit'

  if (!["view", "edit"].includes(permission)) {
    return res.status(400).json({ error: "permission must be 'view' or 'edit'" });
  }

  // TODO: look up the target user by email, then:
  // INSERT INTO shares (file_id, shared_by, shared_with, permission)
  // VALUES (fileId, req.user.sub, targetUserId, permission)

  res.json({ fileId, sharedWith: email, permission });
});

// Create a shareable link (optionally expiring).
router.post("/:fileId/link", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  const { permission = "view", expiresInHours } = req.body;

  const linkToken = crypto.randomBytes(24).toString("hex"); // unguessable, not sequential
  const expiresAt = expiresInHours
    ? new Date(Date.now() + expiresInHours * 3600 * 1000)
    : null;

  // TODO: INSERT INTO shares (file_id, shared_by, permission, link_token, expires_at)
  // VALUES (fileId, req.user.sub, permission, linkToken, expiresAt)

  res.json({
    fileId,
    shareUrl: `https://myapp.example.com/shared/${linkToken}`,
    permission,
    expiresAt,
  });
});

// Access a file via its share link (no login required for public links).
router.get("/link/:linkToken", async (req, res) => {
  const { linkToken } = req.params;
  // TODO: SELECT * FROM shares WHERE link_token = linkToken
  //       AND (expires_at IS NULL OR expires_at > now())
  // If found, look up the file's current version and issue a download URL.
  res.json({ linkToken, status: "not_implemented_wire_up_db" });
});

// Revoke a share.
router.delete("/:shareId", requireAuth, async (req, res) => {
  const { shareId } = req.params;
  // TODO: DELETE FROM shares WHERE id = shareId AND shared_by = req.user.sub
  res.json({ shareId, revoked: true });
});

module.exports = router;
