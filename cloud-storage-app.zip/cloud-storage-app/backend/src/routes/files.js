const express = require("express");
const { v4: uuidv4 } = require("uuid");
const router = express.Router();
const { requireAuth } = require("../auth");
const { getUploadUrl, getDownloadUrl } = require("../s3");

// In a real app these all read/write Postgres via `db/schema.sql`.
// Left as clear TODOs so the wiring is obvious.

// 1. Client asks for a place to upload a new file.
router.post("/upload-url", requireAuth, async (req, res) => {
  const { fileName, contentType } = req.body;
  if (!fileName) return res.status(400).json({ error: "fileName is required" });

  const fileId = uuidv4();
  const versionId = uuidv4();

  const { url, key } = await getUploadUrl(req.user.sub, fileId, versionId, contentType);

  // TODO: INSERT INTO files (id, owner_id, name, mime_type, status) VALUES (...)
  // TODO: INSERT INTO file_versions (id, file_id, s3_key, uploaded_by) VALUES (...)

  res.json({ fileId, versionId, uploadUrl: url, s3Key: key });
});

// 2. Client confirms the upload finished — mark the file active.
router.post("/:fileId/complete", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  // TODO: UPDATE files SET status = 'active', current_version_id = ... WHERE id = fileId
  res.json({ fileId, status: "active" });
});

// 3. List the current user's files (owned + shared with them).
router.get("/", requireAuth, async (req, res) => {
  // TODO: SELECT * FROM files WHERE owner_id = req.user.sub AND status = 'active'
  //       UNION with files joined through the shares table
  res.json({ files: [] });
});

// 4. Get a download URL for a file's current version.
router.get("/:fileId/download", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  // TODO: look up the file's current_version_id -> s3_key, and confirm
  // req.user.sub is either the owner or has a share row for this file.
  const s3Key = `users/${req.user.sub}/files/${fileId}/placeholder-version`;
  const url = await getDownloadUrl(s3Key, "download");
  res.json({ downloadUrl: url });
});

// 5. Soft-delete a file.
router.delete("/:fileId", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  // TODO: UPDATE files SET status = 'deleted' WHERE id = fileId AND owner_id = req.user.sub
  res.json({ fileId, status: "deleted" });
});

module.exports = router;
