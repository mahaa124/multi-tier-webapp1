const express = require("express");
const { v4: uuidv4 } = require("uuid");
const router = express.Router();
const { requireAuth } = require("../auth");
const { getUploadUrl } = require("../s3");

// List all versions of a file, newest first.
router.get("/:fileId", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  // TODO: SELECT * FROM file_versions WHERE file_id = fileId ORDER BY created_at DESC
  res.json({ fileId, versions: [] });
});

// Upload a new version of an existing file (same flow as a fresh
// upload, but appends to file_versions instead of creating a new file).
router.post("/:fileId/new", requireAuth, async (req, res) => {
  const { fileId } = req.params;
  const { contentType } = req.body;
  const versionId = uuidv4();

  const { url, key } = await getUploadUrl(req.user.sub, fileId, versionId, contentType);
  // TODO: INSERT INTO file_versions (id, file_id, s3_key, uploaded_by) VALUES (...)

  res.json({ fileId, versionId, uploadUrl: url, s3Key: key });
});

// Restore an older version — just re-points current_version_id,
// no data movement required since the old object is still in S3.
router.post("/:fileId/restore/:versionId", requireAuth, async (req, res) => {
  const { fileId, versionId } = req.params;
  // TODO: UPDATE files SET current_version_id = versionId WHERE id = fileId
  // TODO: INSERT INTO audit_log (user_id, file_id, action) VALUES (req.user.sub, fileId, 'restore_version')
  res.json({ fileId, currentVersionId: versionId });
});

module.exports = router;
