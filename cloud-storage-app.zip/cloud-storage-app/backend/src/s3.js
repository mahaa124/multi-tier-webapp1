const { S3Client, PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const s3 = new S3Client({ region: process.env.AWS_REGION });
const BUCKET = process.env.S3_BUCKET_NAME;

// Key convention: users/{userId}/files/{fileId}/{versionId}
// Prefixing every key with the owner's ID keeps storage isolated per user.
function buildKey(userId, fileId, versionId) {
  return `users/${userId}/files/${fileId}/${versionId}`;
}

async function getUploadUrl(userId, fileId, versionId, contentType) {
  const key = buildKey(userId, fileId, versionId);
  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType,
  });
  const url = await getSignedUrl(s3, command, { expiresIn: 300 }); // 5 minutes
  return { url, key };
}

async function getDownloadUrl(key, downloadFileName) {
  const command = new GetObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ResponseContentDisposition: downloadFileName
      ? `attachment; filename="${downloadFileName}"`
      : undefined,
  });
  return getSignedUrl(s3, command, { expiresIn: 300 });
}

module.exports = { buildKey, getUploadUrl, getDownloadUrl };
