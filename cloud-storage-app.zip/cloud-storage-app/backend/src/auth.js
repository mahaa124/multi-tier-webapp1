const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();

const {
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  OAUTH_REDIRECT_URI,
  JWT_SECRET,
} = process.env;

// Step 1: redirect the browser to Google's consent screen.
router.get("/google", (req, res) => {
  const params = new URLSearchParams({
    client_id: GOOGLE_CLIENT_ID,
    redirect_uri: OAUTH_REDIRECT_URI,
    response_type: "code",
    scope: "openid email profile",
    access_type: "offline",
    prompt: "consent",
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
});

// Step 2: Google redirects back here with an auth code.
router.get("/google/callback", async (req, res) => {
  const { code } = req.query;
  if (!code) return res.status(400).json({ error: "Missing auth code" });

  try {
    // Exchange the code for tokens — this happens server-side only,
    // so the client secret never reaches the browser.
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: GOOGLE_CLIENT_ID,
        client_secret: GOOGLE_CLIENT_SECRET,
        redirect_uri: OAUTH_REDIRECT_URI,
        grant_type: "authorization_code",
      }),
    });
    const tokens = await tokenRes.json();

    // Fetch the user's profile using the access token.
    const profileRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const profile = await profileRes.json();

    // TODO: look up or create the user row in Postgres here, e.g.:
    // const user = await findOrCreateUser({
    //   email: profile.email, name: profile.name,
    //   oauth_provider: "google", oauth_sub: profile.id,
    // });
    const user = { id: profile.id, email: profile.email, name: profile.name };

    // Issue our own short-lived session JWT — the frontend only ever
    // sees this, never Google's tokens.
    const sessionToken = jwt.sign(
      { sub: user.id, email: user.email, name: user.name },
      JWT_SECRET,
      { expiresIn: "1h" }
    );

    // In production, set this as an httpOnly cookie rather than a query param.
    res.cookie("session", sessionToken, { httpOnly: true, secure: true, sameSite: "lax" });
    res.redirect("http://localhost:3000/?login=success");
  } catch (err) {
    console.error("OAuth callback error:", err);
    res.status(500).json({ error: "Authentication failed" });
  }
});

// Middleware other routes use to require a valid session.
function requireAuth(req, res, next) {
  const token = req.cookies?.session || req.headers.authorization?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ error: "Not authenticated" });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Invalid or expired session" });
  }
}

module.exports = router;
module.exports.requireAuth = requireAuth;
