require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./auth");
const filesRoutes = require("./routes/files");
const versionsRoutes = require("./routes/versions");
const sharesRoutes = require("./routes/shares");

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({ credentials: true, origin: true }));
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", service: "cloud-storage-backend", timestamp: new Date().toISOString() });
});

app.use("/auth", authRoutes);
app.use("/api/files", filesRoutes);
app.use("/api/versions", versionsRoutes);
app.use("/api/shares", sharesRoutes);

app.listen(PORT, () => {
  console.log(`Cloud storage backend listening on port ${PORT}`);
});
